<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">

    <!-- Text to Speech JS -->

    <title>SCP Foundation</title>
  </head>
  <body class="container">
    
      <div class="bg-dark jumbotron" style="margin-bottom: 0px;">
          <h1 class="display-3 text-light">SCP Foundation</h1>
      </div>
    
    <?php 
        $scp = json_decode(file_get_contents('scpfiles.json'));
    ?>

    <?php foreach($scp as $key=>$display): ;?>
        
        <div class="card bg-secondary text-light" style="margin-top: 5px">
            <div class="card-header bg-dark text-light">
            <h3 id="item<?php echo $key?>">Item: <?php echo $display->Item; ?></h3>
            <h4 id="object<?php echo $key?>">Object: <?php echo $display->Object; ?></h4>
            </div>
            <div class="card-body text-light">
                <h5 class="card-title">Special Containment Procedures</h5>
                <p class="card-text" id="containment<?php echo $key?>"><?php echo $display->Containment; ?></p>
                <h5 class="card-title">Description</h5>
                <p class="card-text" id="description<?php echo $key?>"><?php echo $display->Description; ?></p>
                <hr>
                <button class="btn btn-outline-light" onclick="TextToSpeech('item<?php echo $key?>')">Read Item</button>
                <button class="btn btn-outline-light" onclick="TextToSpeech('object<?php echo $key?>')">Read Object</button>
                <button class="btn btn-outline-light" onclick="TextToSpeech('containment<?php echo $key?>')">Read Special Containment Procedures</button>
                <button class="btn btn-outline-light" onclick="TextToSpeech('description<?php echo $key?>')">Read Description</button>
            </div>
        </div>
        
        
        
        
    <?php endforeach; ?>
    
        <script>
        function TextToSpeech(a){
            const speech = new SpeechSynthesisUtterance();
            let voices = speechSynthesis.getVoices();
            let convert = document.getElementById(a).innerHTML;
            speech.text = convert;
            speech.volume = 1;
            speech.rate = 1;
            speech.pitch = 1
            speech.voice = voices[1];
            window.speechSynthesis.cancel();
            window.speechSynthesis.speak(speech);
        }
        </script>
    

    <!-- Option 1: jQuery and Bootstrap Bundle (includes Popper) -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
  </body>
</html>